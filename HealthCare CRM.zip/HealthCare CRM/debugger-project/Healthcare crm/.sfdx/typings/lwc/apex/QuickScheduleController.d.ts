declare module "@salesforce/apex/QuickScheduleController.getPatients" {
  export default function getPatients(): Promise<any>;
}
declare module "@salesforce/apex/QuickScheduleController.createAppointment" {
  export default function createAppointment(param: {patientId: any, appointmentDateTimeLocal: any}): Promise<any>;
}
