declare module "@salesforce/apex/UpcomingFollowupsController.getUpcomingFollowUps" {
  export default function getUpcomingFollowUps(param: {patientId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpcomingFollowupsController.createFollowUp" {
  export default function createFollowUp(param: {patientId: any, followUpDateStr: any}): Promise<any>;
}
