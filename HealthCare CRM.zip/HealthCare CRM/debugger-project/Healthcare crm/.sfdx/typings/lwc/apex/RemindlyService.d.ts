declare module "@salesforce/apex/RemindlyService.sendSms" {
  export default function sendSms(param: {phone: any, messageBody: any}): Promise<any>;
}
